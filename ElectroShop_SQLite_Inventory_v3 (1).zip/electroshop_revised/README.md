# ElectroShop — Cơ sở dữ liệu tồn kho SQLite

Bản này kết nối website với cơ sở dữ liệu SQLite thật dùng module tích hợp `node:sqlite` của Node.js (file `data/inventory.sqlite`). Website tự tạo database và nhập dữ liệu mẫu từ `data/inventory.csv` trong lần chạy đầu tiên.

## 1. Chạy website trên máy tính
1. Cài Node.js 22.13 trở lên: https://nodejs.org/
2. Giải nén toàn bộ ZIP.
3. Mở Terminal/CMD tại thư mục có `package.json`.
4. Chạy `npm install`.
5. Chạy `npm start`.
6. Mở http://localhost:3000.

Không mở `public/index.html` bằng cách nhấp đúp (`file://`), vì khi đó API và database không hoạt động.

## 2. Hiển thị tồn kho và hết hàng
- Website gọi `GET /api/inventory` để đọc trực tiếp dữ liệu từ SQLite.
- Mỗi sản phẩm hiện số lượng còn lại; số lượng bằng 0 sẽ hiện nhãn **HẾT HÀNG**, dòng **Tạm hết hàng** và khóa nút thêm vào giỏ.
- Dòng thông báo phía trên danh sách cho biết tổng tồn kho và số sản phẩm hết hàng.
- Giỏ hàng không cho tăng số lượng vượt tồn kho.

## 3. Cập nhật số lượng sản phẩm
Đóng/mở Terminal tại thư mục dự án và chạy lệnh, ví dụ:

```bash
npm run stock -- 1 0
```

Lệnh trên đặt tồn kho iPhone (mã 1) về 0; website sẽ hiện HẾT HÀNG sau khi tải lại dữ liệu. Ví dụ đặt lại còn 12:

```bash
npm run stock -- 1 12
```

Mã sản phẩm hiện tại:

| Mã | Sản phẩm |
|---:|---|
| 1 | iPhone 16 Pro |
| 2 | Samsung Galaxy S25 Ultra |
| 3 | MacBook Air M4 13 inch |
| 4 | ASUS ROG Zephyrus G16 |
| 5 | iPad Air M3 |
| 6 | Sony WH-1000XM6 |
| 7 | Apple Watch Series 11 |
| 8 | Anker 737 Power Bank |

Database được tạo ở `data/inventory.sqlite`. Nếu muốn đặt database ở nơi khác, đặt biến môi trường `DATABASE_PATH` trước khi chạy server.

## 4. Khi khách đặt hàng
Website gửi giỏ hàng đến `POST /api/orders`. Server kiểm tra tồn kho và trừ số lượng trong một transaction SQLite; nếu không đủ hàng, đơn bị từ chối và tồn kho không bị trừ dở dang. Sau khi đặt thành công, website tải lại số lượng mới.

## 5. API
- `GET /api/health`: kiểm tra server/database.
- `GET /api/inventory`: trả danh sách tồn kho, có `HetHang` (1 nếu hết hàng).
- `POST /api/orders`: tạo đơn demo và trừ kho; body ví dụ:

```json
{"items":[{"id":1,"quantity":2},{"id":5,"quantity":1}]}
```

## 6. Lưu ý khi đưa lên Internet
Cần hosting chạy Node.js và ổ đĩa bền vững (persistent disk/volume) để giữ file SQLite qua các lần khởi động hoặc deploy. Không dùng static hosting chỉ chứa HTML. Đây là nền tảng quản lý tồn kho/đặt hàng demo; trước khi bán hàng thật cần bổ sung đăng nhập quản trị, bảo vệ API, thông tin khách hàng, thanh toán, sao lưu và chính sách bảo mật. Không đưa mật khẩu hoặc khóa bí mật vào mã nguồn.
